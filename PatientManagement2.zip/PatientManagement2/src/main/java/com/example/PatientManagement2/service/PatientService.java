package com.example.PatientManagement2.service;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.example.PatientManagement2.model.Address;
import com.example.PatientManagement2.model.Billing;
import com.example.PatientManagement2.model.LabTest;
import com.example.PatientManagement2.model.OPVisit;
import com.example.PatientManagement2.model.Patient;
import com.example.PatientManagement2.repo.PatientRepository;
import com.github.javafaker.Faker;

@Service
public class PatientService {
	@Autowired
	private PatientRepository patientRepository;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	public List<Patient> getAllPatients() {
		return mongoTemplate.findAll(Patient.class);
		}

	private final Faker faker = new Faker(); //creates new instsance of Faker class

	public void generatePatients(int count) {
	for (int i = 0; i < count; i++) {
	Patient patient = new Patient();
	patient.setName(faker.name().fullName());//generates random name using faker and set it to patient
	patient.setAge(faker.number().numberBetween(18, 100));
	patient.setAddresses(generateAddresses());
	patient.setOpVisits(generateOPVisits());
	patient.setBillings(generateBillings());
	patient.setLabTests(generateLabTests());
	patientRepository.save(patient);
	}
	}

	private List generateAddresses() {
	List addresses = new ArrayList<>();
	for (int i = 0; i < faker.number().numberBetween(1, 3); i++) {
	Address address = new Address();
	address.setStreet(faker.address().streetAddress());
	address.setCity(faker.address().city());
	address.setState(faker.address().stateAbbr());
	address.setZipCode(faker.address().zipCode());
	addresses.add(address);
	}
	return addresses;
	}

	private List generateOPVisits() {
	List opVisits = new ArrayList<>();
	for (int i = 0; i < faker.number().numberBetween(1, 5); i++) {
	OPVisit opVisit = new OPVisit();
	opVisit.setDate(faker.date().between(faker.date().birthday(10, 50), new Date()));
	opVisit.setDoctorName(faker.name().fullName());
	opVisit.setDescription(faker.lorem().sentence());
	opVisits.add(opVisit);
	}
	return opVisits;
	}

	private List<Billing> generateBillings() {
	List<Billing> billings = new ArrayList<>();
	for (int i = 0; i < faker.number().numberBetween(1, 10); i++) {
	Billing billing = new Billing();
	billing.setDescription(faker.lorem().sentence());
	billing.setAmount(faker.number().randomDouble(2, 10, 1000));
	billings.add(billing);
	}
	return billings;
	}

	private List<LabTest> generateLabTests() {
	List<LabTest> labTests = new ArrayList<>();
	for (int i = 0; i < faker.number().numberBetween(1, 5); i++) {
	LabTest labTest = new LabTest();
	labTest.setName(faker.lorem().word());
	labTest.setDescription(faker.lorem().sentence());
	labTests.add(labTest);
	}
	return labTests;
	}

	}
	


