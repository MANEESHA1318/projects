package com.example.PatientManagement2.model;

public class Billing {
	private String description;
	private Double amount;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setAmount(String price) {
		// TODO Auto-generated method stub
		
	}
	
}
