package com.mphasis.event.Training.Services;

import java.util.List;
import java.util.Optional;
import java.util.Set;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mphasis.event.Training.Model.Nominations;
import com.mphasis.event.Training.Model.Training;
import com.mphasis.event.Training.Repository.NominationRepository;
import com.mphasis.event.Training.Repository.TrainingRepository;


@Service
public class NominationService {

    @Autowired
    private NominationRepository nominationRepository;

    @Autowired
    private TrainingRepository trainingRepository;

    public void saveNomination(Nominations nominationObj) {
    	nominationRepository.save(nominationObj);
    }

    public List<Nominations> fetchNominationsDetails() {
		List<Nominations> NominationsDetailsList= nominationRepository.findAll();
		return NominationsDetailsList;		
	}

    public void deleteNomination(Long NominId) {
    	
    	nominationRepository.deleteById(NominId);
    }

    public Nominations assignTrainingsToNominations(Long NominId, Integer Tid) {
        Set<Training> trainingSet = null;
        Nominations nomination = nominationRepository.findById(NominId).get();
        Training training = trainingRepository.findById(Tid).get();
        trainingSet =  nomination.getAssignedTrainings();
        trainingSet.add(training);
        nomination.setAssignedTrainings(trainingSet);
        return nominationRepository.save(nomination);
    }

    public Nominations getNominationsDetails(Long NominId) { 
  	  Optional<Nominations> optional= nominationRepository.findById(NominId);
  	 Nominations nomdetail=optional.get();
  	  return nomdetail;
  }
  }