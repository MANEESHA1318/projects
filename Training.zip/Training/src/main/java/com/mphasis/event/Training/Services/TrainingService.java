package com.mphasis.event.Training.Services;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.event.Training.Model.Training;
import com.mphasis.event.Training.Repository.TrainingRepository;
@Service
public class TrainingService {
	@Autowired
	 TrainingRepository trainingRepository;	
	@Transactional
	public List<Training> fetchTrainingDetails() {
		List<Training> trainingList=trainingRepository.findAll();
		return trainingList;		
	}
	@Transactional
	public Training saveTrainingDetails(Training trainingdetails) {		
		return trainingRepository.save(trainingdetails);		
	}
	@Transactional
	public void updateTrainingDetails(Training trainingdetails) {
		trainingRepository.save(trainingdetails);		
	}	
	@Transactional
	public void deleteTrainingdetails(int Id) {	
		System.out.println("Trainingdetails  deleted");
		trainingRepository.deleteById(Id);	
	}
	@Transactional 
	  public Training getTrainingDetails(int Id) { 
	  Optional<Training> optional= trainingRepository.findById(Id);
	  Training Traingdetail=optional.get();
	  return Traingdetail;
}
}
