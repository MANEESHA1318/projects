package com.mphasis.event.Training.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.event.Training.Model.Nominations;



public interface NominationRepository extends JpaRepository<Nominations, Long> {
   

}
