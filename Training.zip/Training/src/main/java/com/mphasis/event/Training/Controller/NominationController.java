package com.mphasis.event.Training.Controller;

import java.util.List;

import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.event.Training.Exception.ResourceNotFoundException;
import com.mphasis.event.Training.Model.Nominations;
import com.mphasis.event.Training.Services.NominationService;

@RestController
@RequestMapping("/api/v1")
public class NominationController {

    @Autowired
    private NominationService nominationService;

    @PostMapping("/save")
    public ResponseEntity<Nominations> saveNomination(@RequestBody Nominations nominationObj) {
    	nominationService.saveNomination(nominationObj);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
    @GetMapping("/nominations")
	public List<Nominations> getNominationDetails() {
		List<Nominations> nomList = nominationService.fetchNominationsDetails();
		return nomList;
	}
    @GetMapping("/nominations/{id}")
	public ResponseEntity<Nominations> getNominationsDetailsById(@PathVariable("id")@Min(1)  Long id)
			throws ResourceNotFoundException
	{
    	Nominations nominationsdetails = nominationService.getNominationsDetails(id);
		return   ResponseEntity.ok().body(nominationsdetails);
	}
    @DeleteMapping(value="nominations/{id}")
    public ResponseEntity<Object> deleteNominations(@PathVariable Long id){
    	nominationService.deleteNomination(id);
    	return new ResponseEntity<>("nomination deleted successsfully", HttpStatus.OK);
    	}
    @PostMapping("/{Nominid}/Training/{Id}")
    public Nominations assignTrainingsToNominations(@PathVariable  Long Nominid,
    		@PathVariable int Id)
    {
        return nominationService.assignTrainingsToNominations(Nominid, Id);
    }
}
