package com.mphasis.event.Training.Model;


import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

import java.util.HashSet;
import java.util.Set;

@Entity
@Data
public class Nominations {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="NominId")
	private Long NominId;
	public Long getNominId() {
		return NominId;
	}
	public void setNominId(Long nominid) {
		NominId = nominid;
	}
	@Column(name="Nominations")
	@NotEmpty
	private String Nominations;
	public String getNominations() {
		return Nominations;
	}
	public void setNominations(String nominations) {
		Nominations = nominations;
	}
	
    @ManyToMany
    @JoinTable(name = "Training_Nomines",
            joinColumns = @JoinColumn(name = "NominId"),
            inverseJoinColumns = @JoinColumn(name = "TId")
    )
    private Set<Training> assignedTrainings = new HashSet<>();

	

	public Set<Training> getAssignedTrainings() {
		return assignedTrainings;
	}

	public void setAssignedTrainings(Set<Training> assignedTrainings) {
		this.assignedTrainings = assignedTrainings;
	}
	

}

	
