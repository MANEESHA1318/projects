package com.mphasis.event.Training;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mphasis.event.Training.Repository.RegistrationDetailsRepository;
import com.mphasis.event.Training.Model.Registration;
import com.mphasis.event.Training.Repository.TrainingRepository;
import com.mphasis.event.Training.Model.Training;
@SpringBootTest
class  TrainingApplicationTests  {
	@Autowired
	RegistrationDetailsRepository registrationdetailsRepository;

	@Test
	
	public void addRegistration() {
		Registration registration = new Registration();
		
		registration.setDate("");
		registration.setDescription("Good");
		registration.setFirstName("Maneesha");
        registration.setLastName("Reddy");
		registration.setMode("Offline");
		registration.setTraining_Name("Backend");
		assertNotNull(registrationdetailsRepository.findById(11).get());
	}
	@Test
	public void AllRegistration() {
		List<Registration> list = registrationdetailsRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	public void Registration() {
		Registration Registration = registrationdetailsRepository.findById(16).get();
		assertEquals(16, Registration.getId());


}
	@Autowired
	TrainingRepository trainingRepository;

	@Test
	
	public void addTraining() {
		Training training = new Training();
		
		training.setFrom_Date("");
		training.setDescription("Good");
		training.setFrom_Date("");
		training.setTo_Date("");
		training.setOffering_Dept(""); 
		training.setMode("Offline");
		training.setTrainer("maneesha");
		training.setTraining_Name("Backend");
		assertNotNull(trainingRepository.findById(11).get());
	}
	@Test
	public void AllTraining() {
		List<Training> list = trainingRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	public void Training() {
		Training Training = trainingRepository.findById(11).get();
		assertEquals(11, Training.getTId());


}
	}