package com.event.Training.Controller;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.event.Training.Exception.ResourceNotFoundException;
import com.event.Training.Model.Registration;
import com.event.Training.Services.RegistrationService;

@CrossOrigin(origins="http://localhost:3000")
@RequestMapping("/api/v1")
@RestController
@Validated
public class RegistrationController {
	@Autowired
	private RegistrationService registrationService;
	// retrieving  all the registration details from the database//
	@GetMapping("/registrationdetails")
	public List<Registration> getRegistrationDetails() {
		List<Registration> regList = registrationService.fetchRegistrationDetails();
		return regList;
	}
	
	// retrieving the registration details by using id from the database //
	@GetMapping("/registrationdetails/{id}")
	public ResponseEntity<Registration> getRegistrationDetailsById(@PathVariable("id")@Min(1)  int id)
			throws ResourceNotFoundException
	{
		Registration registrationdetails = registrationService.getRegistrationDetails(id);
		return   ResponseEntity.ok().body(registrationdetails);
	}
	// adding the RegistrationDetails to the database//
	@PostMapping("/registrationdetails")
	public Registration addRegistrationDetails(@RequestBody @Valid Registration regdetail) {
		Registration registrationdetails = registrationService.saveRegistrationDetails(regdetail);
		return registrationdetails;
	}
	
	
	//update the RegistrationDetails details using the id//
	@PutMapping("/registrationdetails/{Id}")
	public ResponseEntity<Registration> updateRegistrationDetails(@Valid @PathVariable int Id,
			@RequestBody Registration registrationDetails) throws ResourceNotFoundException {
		Registration registrations = registrationService.getRegistrationDetails(Id);
		registrations.setId(registrationDetails.getId());
		registrations.setFirstName(registrationDetails.getFirstName());
		registrations.setLastName(registrationDetails.getLastName());
		registrations.setMobile(registrationDetails.getMobile());
		registrations.setTraining_Name(registrationDetails.getTraining_Name());
		registrations.setMode(registrationDetails.getMode());
		registrations.setDescription(registrationDetails.getDescription());
		registrations.setDate(registrationDetails.getDate());		
		final Registration updatedRegistrationDetails = registrationService.saveRegistrationDetails(registrations);
		return ResponseEntity.ok(updatedRegistrationDetails);
	}
            //deleting RegistrationDetails by id//
	@DeleteMapping(value = "/registrationdetails/{id}")
	public ResponseEntity<Object> deleteRegistrationDetails(@PathVariable("id")@Min(1)  int id) {
		registrationService.deleteRegistrationDetails(id);
		return new ResponseEntity<>("Registrationdetails deleted successsfully ", HttpStatus.OK);
	}
}
