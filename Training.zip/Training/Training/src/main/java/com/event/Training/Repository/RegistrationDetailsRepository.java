package com.event.Training.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.event.Training.Model.Registration;




@Repository
public interface RegistrationDetailsRepository extends JpaRepository<Registration ,Integer>  {

	
}
