package com.event.Training.Services;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.event.Training.Model.Registration;
import com.event.Training.Repository.RegistrationDetailsRepository;

@Service
public class RegistrationService {
	@Autowired
	RegistrationDetailsRepository registrationdetailsrepository;	
	@Transactional
	public List<Registration> fetchRegistrationDetails() {
		List<Registration> RegistrationDetailsList= registrationdetailsrepository.findAll();
		return RegistrationDetailsList;		
	}
	@Transactional
	public Registration saveRegistrationDetails(Registration  registrationdetails) {		
		return registrationdetailsrepository.save(registrationdetails);		
	}
	@Transactional
	public void updateRegistrationDetails(Registration regdetails) {
		registrationdetailsrepository.save(regdetails);		
	}	
	@Transactional
	public void deleteRegistrationDetails(int Id) {	
		System.out.println("registration deleted");
		registrationdetailsrepository.deleteById(Id);	
	}
	@Transactional 
	  public Registration getRegistrationDetails(int Id) { 
	  Optional<Registration> optional= registrationdetailsrepository.findById(Id);
	  Registration regdetail=optional.get();
	  return regdetail;
}
}
