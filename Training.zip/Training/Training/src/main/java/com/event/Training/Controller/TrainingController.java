package com.event.Training.Controller;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.event.Training.Exception.ResourceNotFoundException;
import com.event.Training.Model.Training;
import com.event.Training.Services.TrainingService;
@CrossOrigin(origins="http://localhost:3000")
@RequestMapping("/api/v2")
@RestController
@Validated
public class TrainingController {
	@Autowired
	private TrainingService trainingService;
	@GetMapping("/trainingdetails")
	public List<Training> getTrainingDetails() {
		List<Training> trainingList = trainingService.fetchTrainingDetails();
		return trainingList;
	}
	
	// retrieving the TrainingDetails  by training name//
	@GetMapping("/trainingdetails/{Id}")
	public ResponseEntity<Training> getTrainingDetailsById(@PathVariable int Id)
			throws ResourceNotFoundException
	{
		Training trainingdetails = trainingService.getTrainingDetails(Id);
		return   ResponseEntity.ok().body(trainingdetails);
	}
	// adding the TrainingDetails//
	@PostMapping("/trainingdetails")
	public Training addTrainingDetails(@RequestBody @Valid Training trningdetails) {
		Training trainingdetails = trainingService.saveTrainingDetails(trningdetails);
		return trainingdetails;
	}
	
	//update the TrainingDetails using the trainingname//
	@PutMapping("/trainingdetails/{Id}")
	public ResponseEntity<Training> updateTrainingDetails(@Valid @PathVariable int Id,
			@RequestBody Training trainingDetails) throws ResourceNotFoundException {
		
		Training training = trainingService.getTrainingDetails(Id);
		training.setId(trainingDetails.getId());
		training.setTraining_Name(trainingDetails.getTraining_Name());
		training.setDescription(trainingDetails.getDescription());
		training.setDuration(trainingDetails.getDuration());
		training.setMode(trainingDetails.getMode());
		final Training updatedTrainingDetails = trainingService.saveTrainingDetails(training);
		return ResponseEntity.ok(updatedTrainingDetails);
	}
            //deleting TrainingDetails by Training_Name//
	@DeleteMapping(value = "/trainingdetails/{Id}")
	public ResponseEntity<Object> deleteTrainingDetails(@PathVariable("Id")@Min(1) int Id) {
		trainingService.deleteTrainingdetails(Id);
		return new ResponseEntity<>("TrainingDetails deleted successsfully", HttpStatus.OK);
	}
}