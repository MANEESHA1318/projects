package com.event.Training.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Nominations")
public class Nominations {
	@Column(name="Training_Name")
	@NotEmpty
	private String Training_Name;
	@Id
	@Column(name="Nominations")
	@NotEmpty
	private String Nominations;
	public String getTraining_Name() {
		return Training_Name;
	}
	public void setTraining_Name(String training_Name) {
		Training_Name = training_Name;
	}
	public String getNominations() {
		return Nominations;
	}
	public void setNominations(String nominations) {
		Nominations = nominations;
	}
	
}
